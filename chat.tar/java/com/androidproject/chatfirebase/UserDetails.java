package com.androidproject.chatfirebase;

/**
 * Created by csi on 9/8/17.
 */

public class UserDetails {
    static String username = "";
    static String password = "";
    static String chatWith = "";
}